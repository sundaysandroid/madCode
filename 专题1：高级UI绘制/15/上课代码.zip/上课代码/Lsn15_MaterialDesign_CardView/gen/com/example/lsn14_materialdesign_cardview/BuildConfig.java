/** Automatically generated file. DO NOT MODIFY */
package com.example.lsn14_materialdesign_cardview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}