/** Automatically generated file. DO NOT MODIFY */
package com.ricky.materialdesign.ab;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}