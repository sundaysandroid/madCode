package com.ricky.pathmeasure;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.Log;
import android.view.View;

public class CustomView extends View {

	private static final String TAG = "ricky";
	private int mViewHeight;
	private int mViewWidth;
	private Paint paint;

	public CustomView(Context context) {
		super(context);
		initPaint();
	}
	
	private void initPaint() {
		paint = new Paint();
		paint.setColor(Color.RED);
		paint.setStyle(Paint.Style.STROKE);
		paint.setStrokeWidth(10);
		
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		mViewHeight = h;
		mViewWidth = w;
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		canvas.translate(mViewWidth/2, mViewHeight/2);
		
//		Path path = new Path();
//		path.lineTo(0, 200);
//		path.lineTo(200, 200);
//		path.lineTo(200, 0);
//		
//		PathMeasure measure = new PathMeasure(path, false);
//		PathMeasure measure2 = new PathMeasure(path, true);
//		Log.i("ricky", "length"+measure.getLength());//600
//		Log.i("ricky","length"+ measure2.getLength());//800
		//forceClosed:����path���Ƶ��Ƿ�رգ�forceClosed=true�����Զ�����path�����պϲ��ֵĳ���
//		
//		canvas.drawPath(path, paint);
		
		//-------------nextContour---------
//		Path path = new Path();
//		//��·����Ч����Ҫ�ر�Ӳ�����٣���
//		path.addRect(-200, -200, 200, 200, Path.Direction.CW);
//		path.addRect(-100, -100, 100, 100, Path.Direction.CW);
//		
//		PathMeasure measure = new PathMeasure(path, false);
//		float length = measure.getLength();
//		boolean nextContour = measure.nextContour();//��ȡ��һ��·�����п���û�ж��·���ˣ�����false
//		float length2 = measure.getLength();
//		Log.i("ricky", "length1:"+length);
//		Log.i("ricky", "length2:"+length2);
//		
//		canvas.drawPath(path, paint);
		
		//----------getSegment:��ȡƬ��---------------
//		Path path = new Path();
//		//��·����Ч����Ҫ�ر�Ӳ�����٣���
//		path.addRect(-200, -200, 200, 200, Path.Direction.CW);
//		
//		PathMeasure measure = new PathMeasure(path, false);
//		float length = measure.getLength();
//		Log.i("ricky", "length1:"+length);
//		canvas.drawPath(path, paint);
//		
//		Path dst = new Path();
//		dst.lineTo(-300, -300);
//		
//		//startWithMoveTo:false����������ʼ���Ƿ�λ��һ���Ľ�����(�Ƿ񱣳�������)��
//		measure.getSegment(200, 600, dst , false);
//		paint.setColor(Color.GREEN);
//		
//		canvas.drawPath(dst, paint);
		
		//------------getPosTan--------------------
		Path path = new Path();
		path.addCircle(0, 0, 300, Path.Direction.CW);
		
		PathMeasure measure = new PathMeasure(path, false);
		float[] pos = new float[2];
		float[] tan = new float[2];//tan=y/x
		measure.getPosTan(measure.getLength()/4, pos , tan );
		Log.i(TAG, "position:x-"+pos[0]+", y-"+pos[1]);
		Log.i(TAG, "tan:x-"+tan[0]+", y-"+tan[1]);
		
		canvas.drawPath(path, paint);
		
	}

}
