package com.ricky.searchview;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Controller2 extends BaseController {

	@Override
	public void draw(Canvas canvas, Paint paint) {
		// TODO Auto-generated method stub
		
	}

}
