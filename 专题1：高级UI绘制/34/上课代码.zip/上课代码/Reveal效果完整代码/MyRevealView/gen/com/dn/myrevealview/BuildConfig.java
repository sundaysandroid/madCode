/** Automatically generated file. DO NOT MODIFY */
package com.dn.myrevealview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}