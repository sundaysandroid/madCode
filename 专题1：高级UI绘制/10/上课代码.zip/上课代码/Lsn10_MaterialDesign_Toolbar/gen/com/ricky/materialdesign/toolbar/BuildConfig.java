/** Automatically generated file. DO NOT MODIFY */
package com.ricky.materialdesign.toolbar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}