package com.ricky.slidingitemmenu;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.test.suitebuilder.annotation.Smoke;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.LinearLayout;
import android.widget.Scroller;

public class SlidingItemMenuLayout extends LinearLayout {

	private Scroller mScroller;
	private View leftChild;
	private View rightChild;

	public SlidingItemMenuLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		setOrientation(LinearLayout.HORIZONTAL);
		mScroller = new Scroller(getContext(), null, true);
	}
	
	@Override
	protected void onFinishInflate() {
		// TODO Auto-generated method stub
		super.onFinishInflate();
		leftChild = getChildAt(0);
		rightChild = getChildAt(1);
	}
	
	private float startX ;
	private float startY ;
	private float dx;
	private float dy;
	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		switch (ev.getAction()) {
		case MotionEvent.ACTION_DOWN:
			startX = ev.getX();
			startY = ev.getY();
			super.dispatchTouchEvent(ev);
			return true;
		case MotionEvent.ACTION_MOVE:
			dx = ev.getX() - startX;
			dy = ev.getY() - startY;
			//dx>0�һ�   <0��
			if(Math.abs(dx) - Math.abs(dy)  > ViewConfiguration.getTouchSlop()){
				//�����ľ��벻�ܴ���rightWidth
				if(getScrollX() + (-dx)>rightChild.getWidth()||getScrollX() + (-dx)<0){
					return true;
				}
				this.scrollBy((int)-dx, 0);
				startX = ev.getX();
				startY = ev.getY();
				return true;
			}
			break;
		case MotionEvent.ACTION_UP:
			
			//����ֻ�ǰѻ���������Ͳ��������ͼ�¼��
			//�жϵ�ǰ�ɿ��������󻬻������һ�
			int offset = (getScrollX()/(float)rightChild.getWidth()) > 0.5f ? rightChild.getWidth()-getScrollX() : -getScrollX();
			mScroller.startScroll(getScrollX(), getScrollY(), offset, 0);
			invalidate();
			startX = 0;
			startY = 0;
			dx = 0;
			dy = 0;
			break;

		default:
			break;
		}
		return super.dispatchTouchEvent(ev);
	}
	
	//�ڿ�������������£�mScroller.startScroll���������Ĺ��̵��д˷����ᱻ���ϵ���
	@Override
	public void computeScroll() {
		if(mScroller.computeScrollOffset()){
			this.scrollTo(mScroller.getCurrX(), mScroller.getCurrY());
			postInvalidate();
		}
	}

}
