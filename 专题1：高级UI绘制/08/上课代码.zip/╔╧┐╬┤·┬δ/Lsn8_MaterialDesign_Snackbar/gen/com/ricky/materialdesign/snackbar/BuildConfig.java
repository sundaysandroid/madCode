/** Automatically generated file. DO NOT MODIFY */
package com.ricky.materialdesign.snackbar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}