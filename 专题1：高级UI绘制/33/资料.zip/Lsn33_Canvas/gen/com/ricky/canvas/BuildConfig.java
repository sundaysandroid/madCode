/** Automatically generated file. DO NOT MODIFY */
package com.ricky.canvas;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}