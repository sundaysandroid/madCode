/** Automatically generated file. DO NOT MODIFY */
package com.ricky.myrevealview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}