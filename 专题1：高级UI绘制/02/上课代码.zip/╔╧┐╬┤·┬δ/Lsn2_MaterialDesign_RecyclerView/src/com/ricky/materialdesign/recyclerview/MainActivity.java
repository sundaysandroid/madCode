package com.ricky.materialdesign.recyclerview;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends Activity {

	private RecyclerView recylerview;
	private ArrayList<String> list;
//	private MyRecyclerAdapter adapter;
	private MyStaggedRecyclerAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		list = new ArrayList<String>();
		for (int i = 0; i < 60; i++) {
			list.add("item"+i);
		}
		
		recylerview = (RecyclerView)findViewById(R.id.recylerview);
//		adapter = new MyRecyclerAdapter(list);
		adapter = new MyStaggedRecyclerAdapter(list);
		//LayoutManager���ְڷŹ�����(���԰ڷš��ٲ���)
//		recylerview.setLayoutManager(new LinearLayoutManager(this));//Ĭ�ϴ�ֱ
		//reverseLayout:���ݵ��ã����ұ߿�ʼ����
//		recylerview.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
//		recylerview.setLayoutManager(new GridLayoutManager(this, 3));
		//�ٲ���Ч��
		recylerview.setLayoutManager(new StaggeredGridLayoutManager(3, LinearLayoutManager.VERTICAL));
		recylerview.setAdapter(adapter);
		
		
	}
}
