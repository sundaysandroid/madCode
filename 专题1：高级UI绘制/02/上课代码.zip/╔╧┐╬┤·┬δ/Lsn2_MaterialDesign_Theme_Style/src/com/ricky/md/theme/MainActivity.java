package com.ricky.md.theme;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.widget.ListPopupWindow;
import android.support.v7.widget.PopupMenu;
import android.view.View;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends Activity {

	private ProgressBar progressBar1;
	private SwipeRefreshLayout srl;
	private ArrayAdapter<String> adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		progressBar1 = (ProgressBar)findViewById(R.id.progressBar1);
		progressBar1.setMax(100);
		progressBar1.setProgress(50);
		
		srl = (SwipeRefreshLayout)findViewById(R.id.srl);
		srl.setSize(SwipeRefreshLayout.LARGE);
		srl.setOnRefreshListener(new OnRefreshListener() {
			
			@Override
			public void onRefresh() {
				// ������� ���ظ�������
				
//				srl.setRefreshing(false);
			}
		});
		srl.setColorSchemeColors(Color.RED,Color.BLUE,Color.GREEN);
		//���ý������ı�����ɫ
		srl.setProgressBackgroundColorSchemeColor(Color.YELLOW);
		//�����������پ��뿪ʼˢ��
//		srl.setDistanceToTriggerSync(70);
		
		String[] items = {"��Ŀ0","��Ŀ1","��Ŀ2","��Ŀ3","��Ŀ4","��Ŀ5","��Ŀ6",};
		//����
		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items );
		
	}
	public void showPopupMenu(View v) {
		PopupMenu popupMenu = new PopupMenu(this, v);
		popupMenu.getMenuInflater().inflate(R.menu.main, popupMenu.getMenu());
//		popupMenu.setOnMenuItemClickListener(listener);
		popupMenu.show();
		
	}
	public void showPopup(View v) {
		final ListPopupWindow listPopupWindow = new ListPopupWindow(this);
		listPopupWindow.setAdapter(adapter);
		//����ê�㣬������λ���������v��λ��
		listPopupWindow.setAnchorView(v);
		listPopupWindow.setWidth(200);
		listPopupWindow.setHeight(500);
		listPopupWindow.show();
		listPopupWindow.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Toast.makeText(getApplicationContext(), "���˵�"+position, 0).show();
				listPopupWindow.dismiss();
			}
		});
	}

	public void showDialog(View v) {
		AlertDialog.Builder builder = new Builder(this);
		builder.setTitle("Ů����");
		builder.setMessage("����һ��Ů����");
		builder.setPositiveButton("ȷ��", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				
			}
		});
		builder.setNegativeButton("ȡ��", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				
			}
		});
		builder.show();
		
	}
	
}
