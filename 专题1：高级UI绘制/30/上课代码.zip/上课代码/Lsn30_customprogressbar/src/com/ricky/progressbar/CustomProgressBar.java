package com.ricky.progressbar;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

public class CustomProgressBar extends View {

	private int max;
	private int roundColor;
	private int roundProgressColor;
	private int textColor;
	private float textSize;
	private float roundWidth;
	private boolean textShow;
	private int style;
	private int progress;
	private Paint paint;
	public static final int STROKE = 0;
	public static final int FILL = 1;

	public CustomProgressBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		paint = new Paint();
		TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.CustomProgressBar);
		max = typedArray.getInteger(R.styleable.CustomProgressBar_max, 100);
		roundColor = typedArray.getColor(R.styleable.CustomProgressBar_roundColor, Color.RED);
		roundProgressColor = typedArray.getColor(R.styleable.CustomProgressBar_roundProgressColor, Color.BLUE);
		textColor = typedArray.getColor(R.styleable.CustomProgressBar_textColor, Color.GREEN);
		textSize = typedArray.getDimension(R.styleable.CustomProgressBar_textSize, 55);
		roundWidth = typedArray.getDimension(R.styleable.CustomProgressBar_roundWidth, 10);
		textShow = typedArray.getBoolean(R.styleable.CustomProgressBar_textShow, true);
		style = typedArray.getInt(R.styleable.CustomProgressBar_style, 0);
		
		typedArray.recycle();
	}

	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		//��Ĭ�ϵĴ�Բ��
		int center = getWidth()/2;//���������
		
		float radius =  center-roundWidth/2;//�뾶
		paint.setColor(roundColor);
		paint.setStyle(Paint.Style.STROKE);//���ÿ���(���)
		paint.setStrokeWidth(roundWidth);//Բ���Ŀ���
		paint.setAntiAlias(true);
		canvas.drawCircle(center, center, radius , paint);
		
		//�����Ȱٷֱ�
//		paint.reset();
		paint.setColor(textColor);
		paint.setStrokeWidth(0);//Բ���Ŀ���
		paint.setTextSize(textSize);
		paint.setTypeface(Typeface.DEFAULT_BOLD);
		
		int percent = (int) (progress/(float)max * 100);
		if(textShow && percent!=0 && style == STROKE){
			canvas.drawText(percent+"%", (getWidth()-paint.measureText(percent+"%"))/2f, 
					//y��ʽ�� float baselineY = centerY + (fontMetrics.bottom-fontMetrics.top)/2 - fontMetrics.bottom
					getWidth()/2f-(paint.descent()+paint.ascent())/2f, 
					paint);
		}
		//��Բ��
		//�������򣬶���Բ������״��С
		RectF oval = new RectF(center-radius, center-radius, center+radius, center+radius);
		paint.setColor(roundProgressColor);
		paint.setStrokeWidth(roundWidth);
		switch (style) {
		case STROKE:
			paint.setStyle(Paint.Style.STROKE);
			canvas.drawArc(oval , 0, 360*progress/max, false, paint);
			break;
		case FILL:
			paint.setStyle(Paint.Style.FILL_AND_STROKE);
			if(progress!=0)
				canvas.drawArc(oval , 0, 360*progress/max, true, paint);
			break;
		}
		
		
	}
	
	public synchronized int getMax(){
		return max;
	}
	
	public synchronized void setMax(){
		if(max<0){
			throw new IllegalArgumentException("max����С��0");
		}
		this.max = max;
	}
	
	public synchronized int getProgress(){
		return progress;
	}
	
	public synchronized void setProgress(int progress){
		if(progress<0){
			throw new IllegalArgumentException("progress����С��0");
		}
		if(progress>max){
			progress = max;
		}
		if(progress <=max){
			this.progress = progress;
			postInvalidate();
		}
	}


	public int getRoundColor() {
		return roundColor;
	}


	public void setRoundColor(int roundColor) {
		this.roundColor = roundColor;
	}


	public int getRoundProgressColor() {
		return roundProgressColor;
	}


	public void setRoundProgressColor(int roundProgressColor) {
		this.roundProgressColor = roundProgressColor;
	}


	public int getTextColor() {
		return textColor;
	}


	public void setTextColor(int textColor) {
		this.textColor = textColor;
	}


	public float getTextSize() {
		return textSize;
	}


	public void setTextSize(int textSize) {
		this.textSize = textSize;
	}


	public float getRoundWidth() {
		return roundWidth;
	}


	public void setRoundWidth(int roundWidth) {
		this.roundWidth = roundWidth;
	}


	public boolean isTextShow() {
		return textShow;
	}


	public void setTextShow(boolean textShow) {
		this.textShow = textShow;
	}
	
}
