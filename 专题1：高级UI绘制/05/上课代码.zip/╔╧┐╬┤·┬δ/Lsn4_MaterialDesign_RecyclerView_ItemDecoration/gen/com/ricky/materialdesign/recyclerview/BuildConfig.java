/** Automatically generated file. DO NOT MODIFY */
package com.ricky.materialdesign.recyclerview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}