package com.dn.waveview2;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

public class WaveView extends View {

	private Paint paint;
	private Path path;
	private int waveLength = 800;
	private int dx;
	private int dy;

	public WaveView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	private void init() {
		paint = new Paint();
		paint.setColor(Color.RED);
		paint.setStyle(Style.FILL_AND_STROKE);
		
		path = new Path();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		path.reset();
		int originY = 500;
		if(dy<originY + 150){
			dy += 30;
		}
		int halfWaveLength = waveLength/2;
		path.moveTo(-waveLength+dx, originY-dy);
		//��Ļ�Ŀ�������Ŷ��ٸ�����
		for (int i = -waveLength; i < getWidth() + waveLength; i += waveLength) {
			//��Ի��ƶ��ױ���������(������Լ�����ʼ��--Ҳ������һ�����ߵ��յ�  �ľ���dx1)
			path.rQuadTo(halfWaveLength/2, -150, halfWaveLength, 0);
			path.rQuadTo(halfWaveLength/2, 150, halfWaveLength, 0);
//			path.quadTo(x1, y1, x2, y2)
			
		}
		//��ɫ���
		//��һ����յĿռ�
		path.lineTo(getWidth(), getHeight());
		path.lineTo(0, getHeight());
		path.close();
		
		canvas.drawPath(path, paint);
	}
	
	public void startAnimation(){
		ValueAnimator animator = ValueAnimator.ofInt(0,waveLength);
		animator.setDuration(1000);
		animator.setInterpolator(new LinearInterpolator());
		//����ѭ��
		animator.setRepeatCount(ValueAnimator.INFINITE);
		animator.addUpdateListener(new AnimatorUpdateListener() {
			
			@Override
			public void onAnimationUpdate(ValueAnimator animation) {
				dx = (int) animation.getAnimatedValue();
				postInvalidate();
			}
		});
		animator.start();
	}
	
}
