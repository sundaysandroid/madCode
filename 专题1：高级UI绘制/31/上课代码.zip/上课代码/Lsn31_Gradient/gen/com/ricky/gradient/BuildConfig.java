/** Automatically generated file. DO NOT MODIFY */
package com.ricky.gradient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}