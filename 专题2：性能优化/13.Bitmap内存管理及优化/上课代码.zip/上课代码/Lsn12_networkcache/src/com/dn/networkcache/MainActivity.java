package com.dn.networkcache;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.HttpStatus;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.net.http.HttpResponseCache;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends Activity {

	protected static final String TAG = "ricky";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void openCache(View v){
		try {
			//AndroidϵͳĬ�ϵ�HttpResponseCache(����������Ӧ����)�ǹرյ�
			//������������������֮�����cacheĿ¼���洴��http���ļ��У�HttpResponseCache�Ỻ�����еķ�����Ϣ
			File cacheDir = new File(getCacheDir(), "http");//����Ŀ¼
			long maxSize = 10*1024*1024;//�����С����λbyte
			HttpResponseCache.install(cacheDir, maxSize );
			Log.d(TAG, "�򿪻���");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void request(View v){
		Log.d(TAG, "~~~~~~~~~~~~~");
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					//10.0.2.2
					HttpURLConnection conn = (HttpURLConnection) new URL("http://192.168.1.115:8080/dn_network_cache_server/MyServlet1").openConnection();
					conn.setRequestMethod("GET");
					conn.setDoInput(true);
					conn.connect();
					int responseCode = conn.getResponseCode();
					if(responseCode==HttpStatus.SC_OK){
						InputStream is = conn.getInputStream();
						BufferedReader br = new BufferedReader(new InputStreamReader(is));
						Log.d(TAG, br.readLine());
					}else{
						Log.d(TAG, responseCode+"");
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					Log.d(TAG, "���󷭳��ˣ���");
				}
			}
		}).start();
	}
	
	public void request2(View v){
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					BitmapFactory.decodeStream((InputStream) new URL("http://192.168.1.115:8080/dn_network_cache_server/icon.png").getContent());
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		}).start();
	}
	
	public void deleteCache(View v){
		HttpResponseCache cache = HttpResponseCache.getInstalled();
		if(cache!=null){
			try {
				cache.delete();
				Log.d(TAG, "��ջ���");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
	}
	
	
	
}
