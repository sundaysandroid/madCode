/** Automatically generated file. DO NOT MODIFY */
package com.example.applicationstartoptimizedemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}