package com.dn.fixutils;

public class MyConstants {
	public static final String DEX_DIR = "odex";
}
