package com.dn.fixutils;

public class TestUtils {
	public  String getTestString(){
		return "new count:";
	}
}
