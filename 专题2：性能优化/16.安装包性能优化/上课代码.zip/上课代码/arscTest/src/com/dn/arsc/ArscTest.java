package com.dn.arsc;

import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import mindprod.ledatastream.LEDataInputStream;

public class ArscTest {
	public static void main(String[] args){
		ArscTest arscTest = new ArscTest();
		try {
//			arscTest.readInputStream("C:/Users/luoding/workspace_test/arscTest/input.apk");
//			arscTest.readInputStream("C:/Users/luoding/workspace_test/arscTest/Lsn10SearchView.apk");
			arscTest.readInputStream("C:/Users/luoding/workspace_test/arscTest/dn_jobschduler.apk");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("resource")
	public void readInputStream(String path) throws IOException{
		ZipFile zipFile = new ZipFile(path);
		InputStream inputStream = zipFile.getInputStream(new ZipEntry(""+"resources.arsc"));
		LEDataInputStream leDataInputStream = new LEDataInputStream(inputStream);
		//Resource Table ͷ
		short type = leDataInputStream.readShort();
		leDataInputStream.skipBytes(2);
		leDataInputStream.readInt();
		int packageNum = leDataInputStream.readInt();
		System.out.println("num of package:"+packageNum);
		
		//StringPool��
		int got =leDataInputStream.readInt();
		//���С
		int chunkSize = leDataInputStream.readInt();
		//�ַ�������
		int stringCount = leDataInputStream.readInt();
		//style����
		int styleCount = leDataInputStream.readInt();
		//���
		int flags = leDataInputStream.readInt();
		//�ַ�����ʼλ��
		int stringsOffset = leDataInputStream.readInt();
		//style��ʼλ��
		int stylesOffset = leDataInputStream.readInt();
		int[] array = new int[stringCount];
		for (int i = 0; i < stringCount; ++i){
			array[i] = leDataInputStream.readInt();
		}
		if (styleCount != 0) {
			for (int i = 0; i < styleCount; ++i)
				array[i] = leDataInputStream.readInt();
		}
		//�ַ�������
		int size = ((stylesOffset == 0) ? chunkSize : stylesOffset) - stringsOffset;
		byte[] m_strings = new byte[size];
		StringBuffer ss = new StringBuffer();
		leDataInputStream.readFully(m_strings); 
		for(int i = 0;i<m_strings.length;i++){
			//(ͨ����resources.arsc����һЩ���� �µó��ַ�����ASCII��)
			char c = (char) m_strings[i];
			ss.append(c);
		}
		System.out.println(ss.toString());
		if (stylesOffset != 0) {
			size = chunkSize - stylesOffset;
			if (size % 4 != 0)
				throw new IOException("Style data size is not multiple of 4 (" + size + ").");

			for (int i = 0; i < size / 4; ++i)
				leDataInputStream.readInt();
		}
		//nextChunk
		leDataInputStream.readShort();
		leDataInputStream.skipBytes(2);
		leDataInputStream.readInt();
		
		int id = (byte) leDataInputStream.readInt();
		StringBuilder sb = new StringBuilder(16);
		int length = 256;
		while (length-- != 0) {
		      short ch = leDataInputStream.readShort();
		      if (ch == 0)
		        break;

		      sb.append((char)ch);
		    }
		System.out.println("pacakgeName:"+sb.toString());
	}
	
	
	
}
