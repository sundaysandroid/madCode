package com.ricky.keepliveprocess.onepixel;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.ricky.keepliveprocess.onepixel.ScreenListener.ScreenStateListener;

public class MyService extends Service {

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		ScreenListener listener = new ScreenListener(this);
		listener.begin(new ScreenStateListener() {
			
			@Override
			public void onUserPresent() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onScreenOn() {
				// ����---finish���һ�����ص�Activity
				KeepLiveActivityManager.getInstance(MyService.this).finishKeepLiveActivity();
			}
			
			@Override
			public void onScreenOff() {
				// ����---����һ�����ص�Activity
//				startActivity(intent);
				KeepLiveActivityManager.getInstance(MyService.this).startKeepLiveActivity();
			}
		});
		
	}

}
